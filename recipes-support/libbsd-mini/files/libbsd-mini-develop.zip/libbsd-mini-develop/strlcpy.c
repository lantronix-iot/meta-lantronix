
#include <string.h>
#include <unistd.h>


size_t strlcpy(char *dst, const char *src, size_t siz)
{
	const char *s = src;
	size_t left = siz;

	if (left) 
    {
		/* Copy string up to the maximum size of the dst buffer */
		while (--left != 0) 
        {
			if ((*dst++ = *s++) == '\0')
            {
				break;
            }
		}
	}

	if (left == 0) 
    {
		/* Not enough room for the string; force NUL-termination */
		if (siz != 0)
        {
			*dst = '\0';
        }
		while (*s++)
        {
			; /* determine total src string length */
        }
	}

	return s - src - 1;
}

