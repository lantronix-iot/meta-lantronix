# bcmdhd-golden_gate
BCMDHD WLAN driver for Golden Gate
