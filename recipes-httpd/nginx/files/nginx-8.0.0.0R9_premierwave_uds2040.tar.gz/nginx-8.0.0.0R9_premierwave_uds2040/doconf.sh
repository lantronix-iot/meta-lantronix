./configure \
        --prefix=/usr/local/nginx \
        --with-http_ssl_module \
        --without-http_ssi_module \
        --without-http_uwsgi_module \
        --with-http_realip_module \
        --without-http_rewrite_module
